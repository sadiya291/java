
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EMS")
public class EMS extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EMS() {
		super();

	}

	Employee employee = new Employee();
	EmployeeDAO empDAO = new EmployeeDAOImplementation();

	/*protected void doSave(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		int empId = Integer.parseInt(request.getParameter("text1"));
		String empname = request.getParameter("text2");
		int age = Integer.parseInt(request.getParameter("text3"));
		double salary = Double.parseDouble(request.getParameter("text4"));

		out.println(empId);
		out.print(empname);
		out.println(age);
		out.println(salary);

		employee.setEmpId(empId);
		employee.setEmpname(empname);
		employee.setAge(age);
		employee.setSalary(salary);

		out.println("before dao object");

		empDAO.save(employee);
	}

	protected void dodelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int empId = Integer.parseInt(request.getParameter("text1"));
		System.out.println("inside parseint");
		employee.setEmpId(empId);
		empDAO.delete(employee, empId);
		response.sendRedirect("deleted.html");

	}

	protected void doUpdate(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int empId = Integer.parseInt(request.getParameter("text1"));
		double hike = Double.parseDouble(request.getParameter("text2"));
		System.out.println("inside parseint");
		employee.setEmpId(empId);
		boolean success = empDAO.update(employee, empId, hike);
		if (success) {
			response.getWriter().append("updated successfully");
		} else
			response.getWriter().append("record not found");

		
	}*/

	
	  protected void singleview(HttpServletRequest request, HttpServletResponse
	  response) throws ServletException, IOException { int
	  empId=Integer.parseInt(request.getParameter("text1"));
	  System.out.println("inside parseint");
	  employee.setEmpId(empId);
	  empDAO.view(employee, empId);
	  
	  PrintWriter out=response.getWriter();
	  out.println(+employee.getEmpId());
	  out.println(employee.getEmpname());
	  out.println(+employee.getAge());
	  out.println(+employee.getSalary());
	  
	  
	  }
	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//doSave(request, response);
		//dodelete(request, response);
		//doUpdate(request, response);
		singleview(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
