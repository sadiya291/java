

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;

public class Database {
	private static final Logger LOG = Logger
			.getLogger(Database.class.getName());

	private static Database database = null;

	private Database() {

	}

	public static Database getDatabaseInstance() {
		if (database == null) {
			database = new Database();
		}
		return database;
	}

	public Connection getDatabaseConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			LOG.info(">> Driver has been loaded");
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/testme", "root", "root");
		} catch (ClassNotFoundException e) {
			LOG.info("Error while loading driver");
		} catch (SQLException e) {
			LOG.info("Error while creating connection");
		}
		return connection;
	}
}
