import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeDAOImplementation implements EmployeeDAO {

	// Connection connection=null;
	PreparedStatement ps = null;

	Connection connection = Database.getDatabaseInstance().getDatabaseConnection();

	public void save(Employee employee) {
		try {

			ps = connection.prepareStatement("INSERT into employee VALUES(?,?,?,?)");

			ps.setInt(1, employee.getEmpId());
			ps.setString(2, employee.getEmpname());
			ps.setInt(3, employee.getAge());
			ps.setDouble(4, employee.getSalary());

			ps.executeUpdate();

		} catch (SQLException e) {
			System.out.println("Unable to save successfully");
		}

	}

	public void delete(Employee employee, int empId) {
		try {
			System.out.println("inside delete");
			ps = connection.prepareStatement("delete from employee where empid=?");
			ps.setInt(1, employee.getEmpId());
			System.out.println("deleted");

			ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public boolean update(Employee employee, int empId, double hike) {
		ResultSet rs = null;
		double hikedSalary = 0;
		double salary = 0;

		try {

			ps = connection.prepareStatement("select * from employee where empid=?");
			System.out.println(empId);
			ps.setInt(1, empId);
			rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					salary = rs.getDouble("salary");
					System.out.println(salary);
				}

				hikedSalary = salary + ((hike * salary) / 100);
				System.out.println(hikedSalary);
				ps = connection.prepareStatement("UPDATE employee SET salary=? where empId=?");
				ps.setDouble(1, hikedSalary);
				ps.setInt(2, empId);
				int rows = ps.executeUpdate();
				if (rows > 0) {
					System.out.println("updated");
					return true;
				} else
					System.out.println("not updsated");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public void view(Employee employee, int empId) { try { ps =
	  connection.prepareStatement("select * from employee where empid=?");
	  
	  ps.setInt(1, empId); ResultSet rs = ps.executeQuery(); if (rs.next()) {
	  employee.setEmpId(rs.getInt(1)); employee.setEmpname(rs.getString(2));
	  employee.setAge(rs.getInt(3)); employee.setSalary(rs.getDouble(4)); } } catch
	  (SQLException e) { // TODO Auto-generated catch block e.printStackTrace();
		  }
	  }
	  
	  }
	 
