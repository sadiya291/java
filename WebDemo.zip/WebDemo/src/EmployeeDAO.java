
public interface EmployeeDAO {
	void save(Employee employee);

	void delete(Employee employee, int empId);

	boolean update(Employee employee, int empId, double hike);
	 void view(Employee employee, int empId);
}
